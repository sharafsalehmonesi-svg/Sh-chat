SH-CHAT Android project

Home URL: https://sharafsalehmonesi-svg.github.io/Sh-chat/

The app loads the published GitHub Pages website in Android WebView, rather than a bundled local HTML copy. Website changes appear in the app after GitHub Pages publishes them and the app reloads the page.

Supabase authentication/session behavior and media uploads should be tested on a physical device. This ZIP is the Android project source, not a built APK.
\nأيقونة التطبيق: تمت إضافة أيقونة SH-CHAT الزرقاء والبيضاء إلى مجلدات mipmap، وربطها في AndroidManifest.xml. هذه ملفات المشروع المصدر؛ يجب بناء APK لتظهر الأيقونة على الهاتف.\n